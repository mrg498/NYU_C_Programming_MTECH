gcc main.c search.c
