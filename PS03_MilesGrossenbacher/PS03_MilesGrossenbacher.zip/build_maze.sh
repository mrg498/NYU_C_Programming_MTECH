gcc maze.c maze_recursion.c
