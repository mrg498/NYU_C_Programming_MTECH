#include <stdio.h>
#include <math.h>
#include <sndfile.h>	/* libsndfile */
#include "wav_reverb.h"
#include "convolve.h"	/* FFT-based convolution */

#define MODE	1

void process_audio(Buf *ibuf, int iframes, int channels, Buf *rbuf, int rframes, Buf *obuf)
{
#if (MODE == 1)
	/* just copy input to output */
	int i, j;
	float *ip, *rp;
	/* for each channel and each frame */

#else
#if (MODE == 2)
	/* do reverberation via time-domain convolution */
	int i, j, k, oframes;
	float *ip, *rp;
	double v, gain, rms_iv, rms_ov;
	/* set initial values */
	rms_iv = 0;
	rms_ov = 0;
	// ToDo: convolve each channel signal with reverb impulse response signal




	//scale to make output rms value be equal to input rms value




#else /* (MODE == 3) */
	/* do reverberation via frequency-domain convolution */
	int i;
	/* for each channel */
	for (i=0; i<channels; i++) {
		/* convolve channel signal with reverb impulse response signal */
		/* frequency domain (FFT) convolution */
		convolve(ibuf->buf[i], rbuf->buf[i], iframes, rframes, obuf->buf[i]);
	}
#endif
#endif
}
