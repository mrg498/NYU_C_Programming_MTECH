//Miles Grossenbacher

#include<stdio.h>

int main()
{
  puts("Hello World!");
  return 0;
}

//puts doesn't use format specifiers
//puts automatically goes to the next line

/* puts is good for static messages because we don't need to worry
about printing variables. Whatever we type into the string is what will be
output onto the screen*/
