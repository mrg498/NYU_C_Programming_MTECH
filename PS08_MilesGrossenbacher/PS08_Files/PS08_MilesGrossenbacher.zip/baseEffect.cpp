#include "baseEffect.h"

baseEffect::baseEffect() {;}
baseEffect::~baseEffect() {;}
